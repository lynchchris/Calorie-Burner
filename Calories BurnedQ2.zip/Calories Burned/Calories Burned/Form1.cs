﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calories_Burned
{
    public partial class CaloriesBurned : Form
    {
        public CaloriesBurned()
        {
            InitializeComponent();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            resultsListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            const double CAL_MIN = 3.9;
            
            resultsListBox.Items.Add("5 minutes" + "\t\t" + "Calories Burned");

            for(int min=5; min<=30; min+=5)
            {
                resultsListBox.Items.Add(min + "\t\t" + min*CAL_MIN);
            }


        }
    }
}
